<?php

ob_start();

$connection = mysqli_connect('localhost', 'root', '','addanalyzers');





?>