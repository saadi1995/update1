<?php 


    if(isset($_POST)) {
    
    echo $_POST['username'];
        
        echo "<br>";
        
        
    echo $_POST['password'];
    
    
    }




//    echo "YES is working";






?>