<?php

	
	echo $_POST['search'];



?>