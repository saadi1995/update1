-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2018 at 12:41 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `energysystemmanage`
--

-- --------------------------------------------------------

--
-- Table structure for table `analyzerreading`
--

CREATE TABLE `analyzerreading` (
  `excel_id` int(12) NOT NULL,
  `date` varchar(250) NOT NULL,
  `valueunits` varchar(250) NOT NULL,
  `unit` varchar(250) NOT NULL,
  `analyzerid` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `analyzerreading`
--

INSERT INTO `analyzerreading` (`excel_id`, `date`, `valueunits`, `unit`, `analyzerid`) VALUES
(351, '2/4/2017 6:05', '16669293', '', 0),
(352, '2/4/2017 7:05', '16669293', '', 0),
(353, '2/4/2017 8:05', '16669293', '', 0),
(354, '2/4/2017 9:05', '16669293', '', 0),
(355, '2/4/2017 10:05', '16669293', '', 0),
(356, '2/4/2017 11:05', '16670480', '', 0),
(357, '2/4/2017 12:05', '16672071', '', 0),
(358, '2/4/2017 13:05', '16673619', '', 0),
(359, '2/4/2017 14:05', '16675155', '', 0),
(360, '2/4/2017 15:05', '16676698', '', 0),
(361, '2/4/2017 16:05', '16678243', '', 0),
(362, '2/4/2017 17:05', '16679755', '', 0),
(363, '2/4/2017 18:05', '16681215', '', 0),
(364, '2/4/2017 19:05', '16682725', '', 0),
(365, '2/4/2017 20:05', '16684274', '', 0),
(366, '2/4/2017 21:05', '16685833', '', 0),
(367, '2/4/2017 22:05', '16687375', '', 0),
(368, '2/4/2017 23:05', '16688850', '', 0),
(369, '2/5/2017 0:05', '16688850', '', 0),
(370, '2/5/2017 1:05', '16688850', '', 0),
(371, '2/5/2017 2:05', '16688850', '', 0),
(372, '2/5/2017 3:05', '16688850', '', 0),
(373, '2/5/2017 4:05', '16688850', '', 0),
(374, '2/5/2017 5:05', '16688850', '', 0),
(375, '2/5/2017 6:05', '16688850', '', 0),
(376, '2/4/2017 6:05', '16669293', '', 0),
(377, '2/4/2017 7:05', '16669293', '', 0),
(378, '2/4/2017 8:05', '16669293', '', 0),
(379, '2/4/2017 9:05', '16669293', '', 0),
(380, '2/4/2017 10:05', '16669293', '', 0),
(381, '2/4/2017 11:05', '16670480', '', 0),
(382, '2/4/2017 12:05', '16672071', '', 0),
(383, '2/4/2017 13:05', '16673619', '', 0),
(384, '2/4/2017 14:05', '16675155', '', 0),
(385, '2/4/2017 15:05', '16676698', '', 0),
(386, '2/4/2017 16:05', '16678243', '', 0),
(387, '2/4/2017 17:05', '16679755', '', 0),
(388, '2/4/2017 18:05', '16681215', '', 0),
(389, '2/4/2017 19:05', '16682725', '', 0),
(390, '2/4/2017 20:05', '16684274', '', 0),
(391, '2/4/2017 21:05', '16685833', '', 0),
(392, '2/4/2017 22:05', '16687375', '', 0),
(393, '2/4/2017 23:05', '16688850', '', 0),
(394, '2/5/2017 0:05', '16688850', '', 0),
(395, '2/5/2017 1:05', '16688850', '', 0),
(396, '2/5/2017 2:05', '16688850', '', 0),
(397, '2/5/2017 3:05', '16688850', '', 0),
(398, '2/5/2017 4:05', '16688850', '', 0),
(399, '2/5/2017 5:05', '16688850', '', 0),
(400, '2/5/2017 6:05', '16688850', '', 0),
(401, '2/4/2017 6:05', '16669293', '', 0),
(402, '2/4/2017 7:05', '16669293', '', 0),
(403, '2/4/2017 8:05', '16669293', '', 0),
(404, '2/4/2017 9:05', '16669293', '', 0),
(405, '2/4/2017 10:05', '16669293', '', 0),
(406, '2/4/2017 11:05', '16670480', '', 0),
(407, '2/4/2017 12:05', '16672071', '', 0),
(408, '2/4/2017 13:05', '16673619', '', 0),
(409, '2/4/2017 14:05', '16675155', '', 0),
(410, '2/4/2017 15:05', '16676698', '', 0),
(411, '2/4/2017 16:05', '16678243', '', 0),
(412, '2/4/2017 17:05', '16679755', '', 0),
(413, '2/4/2017 18:05', '16681215', '', 0),
(414, '2/4/2017 19:05', '16682725', '', 0),
(415, '2/4/2017 20:05', '16684274', '', 0),
(416, '2/4/2017 21:05', '16685833', '', 0),
(417, '2/4/2017 22:05', '16687375', '', 0),
(418, '2/4/2017 23:05', '16688850', '', 0),
(419, '2/5/2017 0:05', '16688850', '', 0),
(420, '2/5/2017 1:05', '16688850', '', 0),
(421, '2/5/2017 2:05', '16688850', '', 0),
(422, '2/5/2017 3:05', '16688850', '', 0),
(423, '2/5/2017 4:05', '16688850', '', 0),
(424, '2/5/2017 5:05', '16688850', '', 0),
(425, '2/5/2017 6:05', '16688850', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `analyzers`
--

CREATE TABLE `analyzers` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `analyzers`
--

INSERT INTO `analyzers` (`id`, `title`) VALUES
(67, 'Analyzer1'),
(68, 'saad');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'saadat.saad2@gmail.com', 'saadat.saad0@gmail.com', '347602146a923872538f3803eb5f3cef'),
(3, 'saadi1996', 'saadi1995@gmail.com', '347602146a923872538f3803eb5f3cef');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `analyzerreading`
--
ALTER TABLE `analyzerreading`
  ADD PRIMARY KEY (`excel_id`);

--
-- Indexes for table `analyzers`
--
ALTER TABLE `analyzers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `analyzerreading`
--
ALTER TABLE `analyzerreading`
  MODIFY `excel_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=426;
--
-- AUTO_INCREMENT for table `analyzers`
--
ALTER TABLE `analyzers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
